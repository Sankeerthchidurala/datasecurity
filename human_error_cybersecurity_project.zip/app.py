from flask import Flask, render_template, request, redirect, url_for
from datetime import datetime
import json, os

app = Flask(__name__)

DATA_FILE = 'submissions.json'

if not os.path.exists(DATA_FILE):
    with open(DATA_FILE, 'w') as f:
        json.dump([], f)

def save_submission(data):
    with open(DATA_FILE, 'r+') as f:
        try:
            arr = json.load(f)
        except Exception:
            arr = []
        arr.append(data)
        f.seek(0)
        json.dump(arr, f, indent=2)
        f.truncate()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit_quiz', methods=['POST'])
def submit_quiz():
    answers = request.form.to_dict()
    key = {'q1': 'b', 'q2': 'a', 'q3': 'c', 'q4': 'a', 'q5': 'b'}
    score = sum(1 for k, v in key.items() if answers.get(k) == v)
    result = {'timestamp': datetime.utcnow().isoformat() + 'Z', 'answers': answers, 'score': score}
    save_submission(result)
    return render_template('result.html', score=score, total=len(key))

@app.route('/report_phish', methods=['POST'])
def report_phish():
    payload = request.form.get('message', '')
    entry = {'timestamp': datetime.utcnow().isoformat() + 'Z', 'message': payload}
    save_submission({'phish_report': entry})
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
